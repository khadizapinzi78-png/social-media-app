# Social Media App
**Presented by: Mir Md Khalid**

## Project Features Overview
1. **Permissions First:** Requests Camera and Files/Storage permissions upon launching.
2. **Terms & Guidelines:** Displays clear safety rules with owner credits ("presented by- Mir Md Khalid").
3. **Authentication:** 
   - Google Login option.
   - Mobile Phone Number + OTP verification screen.
   - User Registration (First Name, Last Name, Email).
4. **Profile Setup:** Nickname, Age, New ID Password, Optional Profile Picture.
5. **Main Dashboard:**
   - **Home Feed:** Create posts (Text, Camera Live Photo, Gallery Media).
   - **Reactions:** Unique Love React button, Commenting, Sharing.
   - **Reels:** Vertical swipe media page.
   - **Profile:** Manage user posts and info.
   - **Settings:** Full user control over account settings.

## How to Build & Publish APK/AAB
1. Extract this ZIP file.
2. Open terminal inside `social_media_app` folder.
3. Run `flutter pub get` to download dependencies.
4. Run `flutter run` on an emulator or connected phone to test live.
5. To generate Android Release bundle for Google Play Store:
   ```bash
   flutter build aab --release
   ```
6. The `.aab` file will be generated at `build/app/outputs/bundle/release/app-release.aab`.
