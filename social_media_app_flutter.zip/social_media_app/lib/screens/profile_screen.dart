import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile')),
      body: ListView(
        children: [
          const SizedBox(height: 20),
          const Center(
            child: CircleAvatar(
              radius: 50,
              child: Icon(Icons.person, size: 50),
            ),
          ),
          const SizedBox(height: 12),
          const Center(
            child: Text(
              'User Nickname',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ),
          const Center(
            child: Text('@usernickname', style: TextStyle(color: Colors.grey)),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.edit),
              label: const Text('Edit Profile'),
            ),
          ),
          const SizedBox(height: 20),
          const Divider(),
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text('My Posts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          const Center(
            child: Padding(
              padding: EdgeInsets.all(30.0),
              child: Text('No posts yet', style: TextStyle(color: Colors.grey)),
            ),
          )
        ],
      ),
    );
  }
}
