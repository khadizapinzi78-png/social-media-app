import 'package:flutter/material.dart';

class ReelsScreen extends StatelessWidget {
  const ReelsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      scrollDirection: Axis.vertical,
      itemCount: 5,
      itemBuilder: (context, index) {
        return Container(
          color: Colors.black,
          child: Stack(
            children: [
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.play_circle_fill, size: 80, color: Colors.white54),
                    const SizedBox(height: 10),
                    Text('Reels Video #${index + 1}', style: const TextStyle(color: Colors.white, fontSize: 18)),
                    const Text('Slide vertically for next Reel', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                  ],
                ),
              ),
              Positioned(
                right: 16,
                bottom: 80,
                child: Column(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.favorite, color: Colors.red, size: 36),
                      onPressed: () {},
                    ),
                    const Text('1.2k', style: TextStyle(color: Colors.white)),
                    const SizedBox(height: 20),
                    IconButton(
                      icon: const Icon(Icons.comment, color: Colors.white, size: 32),
                      onPressed: () {},
                    ),
                    const Text('300', style: TextStyle(color: Colors.white)),
                    const SizedBox(height: 20),
                    IconButton(
                      icon: const Icon(Icons.share, color: Colors.white, size: 32),
                      onPressed: () {},
                    ),
                    const Text('Share', style: TextStyle(color: Colors.white)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
