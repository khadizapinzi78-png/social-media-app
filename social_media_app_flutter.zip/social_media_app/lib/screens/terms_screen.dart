import 'package:flutter/material.dart';
import 'login_screen.dart';

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Terms & Rules', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Community Rules & Guidelines',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView(
                  children: const [
                    ListTile(
                      leading: Icon(Icons.block, color: Colors.red),
                      title: Text('No Obscene or Indecent Activity'),
                      subtitle: Text('Sharing explicit, adult, or vulgar content is strictly prohibited.'),
                    ),
                    ListTile(
                      leading: Icon(Icons.warning_amber, color: Colors.orange),
                      title: Text('No Dangerous or Harmful Content'),
                      subtitle: Text('Do not post scary, violent, gory, or dangerous activities.'),
                    ),
                    ListTile(
                      leading: Icon(Icons.gavel, color: Colors.purple),
                      title: Text('No Religious or Hate Discrimination'),
                      subtitle: Text('Any disrespect, insult, or harassment targeting religion, race, or caste is banned.'),
                    ),
                    ListTile(
                      leading: Icon(Icons.chat_bubble_outline, color: Colors.teal),
                      title: Text('No Abusive Language'),
                      subtitle: Text('Profanity, slurs, threats, and toxic behaviour will result in permanent suspension.'),
                    ),
                  ],
                ),
              ),
              const Divider(),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12.0),
                child: Center(
                  child: Text(
                    'presented by- Mir Md Khalid',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueGrey,
                      letterSpacing: 1.1,
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const LoginScreen()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('I Agree & Accept', style: TextStyle(fontSize: 16, color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
