import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class HomeFeedScreen extends StatefulWidget {
  const HomeFeedScreen({super.key});

  @override
  State<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends State<HomeFeedScreen> {
  final List<Map<String, dynamic>> _posts = [
    {
      'author': 'Mir Md Khalid',
      'time': '10 mins ago',
      'text': 'Welcome to Social Media! Express yourself freely and respectfully.',
      'loveCount': 24,
      'isLoved': false,
      'comments': ['Awesome platform!', 'Proud of this project!'],
    },
  ];

  final TextEditingController _postTextController = TextEditingController();

  void _addPost() async {
    if (_postTextController.text.isNotEmpty) {
      setState(() {
        _posts.insert(0, {
          'author': 'User Nickname',
          'time': 'Just now',
          'text': _postTextController.text,
          'loveCount': 0,
          'isLoved': false,
          'comments': [],
        });
        _postTextController.clear();
      });
      Navigator.pop(context);
    }
  }

  void _openCreatePostModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 16, right: 16, top: 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Create Post', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            TextField(
              controller: _postTextController,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: "What's on your mind?",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.photo, color: Colors.green),
                  onPressed: () async {
                    final picker = ImagePicker();
                    await picker.pickImage(source: ImageSource.gallery);
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.camera_alt, color: Colors.blue),
                  onPressed: () async {
                    final picker = ImagePicker();
                    await picker.pickImage(source: ImageSource.camera);
                  },
                ),
                const Spacer(),
                ElevatedButton(
                  onPressed: _addPost,
                  child: const Text('Post'),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Social Media', style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 22)),
        actions: [
          IconButton(icon: const Icon(Icons.add_circle_outline, color: Colors.blue, size: 28), onPressed: _openCreatePostModal),
        ],
      ),
      body: ListView.builder(
        itemCount: _posts.length,
        itemBuilder: (context, index) {
          final post = _posts[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(child: Icon(Icons.person)),
                    title: Text(post['author'], style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(post['time']),
                  ),
                  Text(post['text'], style: const TextStyle(fontSize: 15)),
                  const SizedBox(height: 12),
                  const Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      // ONLY Love React allowed
                      InkWell(
                        onTap: () {
                          setState(() {
                            post['isLoved'] = !post['isLoved'];
                            post['loveCount'] += post['isLoved'] ? 1 : -1;
                          });
                        },
                        child: Row(
                          children: [
                            Icon(
                              Icons.favorite,
                              color: post['isLoved'] ? Colors.red : Colors.grey,
                            ),
                            const SizedBox(width: 4),
                            Text('${post['loveCount']} Love', style: TextStyle(color: post['isLoved'] ? Colors.red : Colors.grey)),
                          ],
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          // Comment dialog
                        },
                        child: const Row(
                          children: [
                            Icon(Icons.comment, color: Colors.grey),
                            SizedBox(width: 4),
                            Text('Comment', style: TextStyle(color: Colors.grey)),
                          ],
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Post link copied to clipboard!')),
                          );
                        },
                        child: const Row(
                          children: [
                            Icon(Icons.share, color: Colors.grey),
                            SizedBox(width: 4),
                            Text('Share', style: TextStyle(color: Colors.grey)),
                          ],
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
